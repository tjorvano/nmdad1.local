    var logOutButtonNav=document.querySelector('#btnLogout');
$('#btnLogout').click(function(){console.log("jquery ftw")});
$('#btnLoginToPage').click(function(){console.log("btn login")});
            
